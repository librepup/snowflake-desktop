/**
 * @name Discord Hider
 * @author Crytix
 * @description Hide selected Discord interface elements using simple, per-item toggles.
 * @version 1.0.0
 * @license MIT
 * @website https://crytix.rocks
 * @source https://github.com/Crytix/bt-discord-hider
 * @updateUrl https://raw.githubusercontent.com/Crytix/bt-discord-hider/main/DiscordHider.plugin.js
 * @changelog
 * [1.0.0]
 * - First public release
 * - Topic-based settings with per-item Discord-style switches
 * - Refactored to a data-driven architecture (options define defaults, UI and behavior)
 */

module.exports = (function () {
  "use strict";

  // -----------------------------
  // Option definitions (single source of truth)
  // -----------------------------
  // Each item:
  // - key: setting key
  // - name: UI label (human-facing)
  // - desc: UI description (human-facing)
  // - css: CSS snippet that implements the behavior
  var OPTION_GROUPS = [
    {
      section: "Quests",
      items: [
        {
          key: "hideQuestPopupsAndContainers",
          name: "Quest pop-ups and banners",
          desc: "Hides quest banners, progress blocks, and quest pop-ups.",
          default: true,
          css: [
            "div[class*=\"questsContainer_\"],",
            "div[class*=\"quest_\"],",
            "div[class*=\"questBanner_\"],",
            "div[class*=\"questProgress_\"] {",
            "  display: none !important;",
            "}"
          ].join("\n")
        },
        {
          key: "hideQuestBadgesOnProfiles",
          name: "Quest badges on profiles",
          desc: "Hides quest completion badges shown on user profiles.",
          default: true,
          css: [
            "div[aria-label^=\"Completed a Quest\"],",
            "div[class*=\"questBadge_\"] {",
            "  display: none !important;",
            "}"
          ].join("\n")
        },
        {
          key: "hideQuestsInDiscoverTab",
          name: "Quest pages in Discover",
          desc: "Hides quest-related entries inside the Discover area.",
          default: true,
          css: [
            "div[class*=\"questTab_\"],",
            "a[href*=\"/quests\"],",
            "div[class*=\"questHome_\"] {",
            "  display: none !important;",
            "}"
          ].join("\n")
        }
      ]
    },

    {
      section: "Upsells & Promotions",
      items: [
        {
          key: "hideProfileEditUpsell",
          name: "Upsell cards in profile editing",
          desc: "Hides promotional cards while editing your profile.",
          default: true,
          css: [
            "div[class^=\"settingsPage_\"] div[class*=\"floatingNitroUpsell_\"],",
            "div[class^=\"settingsPage_\"] div[class*=\"tryItOutSection_\"] {",
            "  display: none !important;",
            "}"
          ].join("\n")
        },
        {
          key: "hideProfileViewUpsell",
          name: "Upsell panel in profile view",
          desc: "Hides promotional panels shown when viewing profiles.",
          default: true,
          css: [
            "aside[class*=\"upsellContainer_\"] {",
            "  display: none !important;",
            "}"
          ].join("\n")
        },
        {
          key: "hideCharacterCountUpsell",
          name: "Upsell in character counter",
          desc: "Hides promotional content near character counters.",
          default: true,
          css: [
            "div[class^=\"characterCount_\"] div[class*=\"upsell_\"] {",
            "  display: none !important;",
            "}"
          ].join("\n")
        },
        {
          key: "hideEmojiInspectionUpsell",
          name: "Upsell in emoji inspection",
          desc: "Hides promotional prompts shown when inspecting emojis or reactions.",
          default: true,
          css: [
            "div[class^=\"emojiSection_\"] button[class^=\"shinyButton_\"],",
            "div[class*=\"burstReactionTooltipPrompt_\"] {",
            "  display: none !important;",
            "}"
          ].join("\n")
        }
      ]
    },

    {
      section: "Chat",
      items: [
        {
          key: "hideGiftButton",
          name: "Send a gift button",
          desc: "Hides the gift button in chat.",
          default: true,
          css: [
            "div[aria-label=\"Send a gift\"] {",
            "  display: none !important;",
            "}"
          ].join("\n")
        },
        {
          key: "hideChannelAppLauncher",
          name: "App launcher button",
          desc: "Hides the app launcher entry point in the message box area.",
          default: true,
          css: [
            "[class$=\"app-launcher-entrypoint\"] {",
            "  display: none !important;",
            "}"
          ].join("\n")
        }
      ]
    },

    {
      section: "DM / Home Navigation",
      items: [
        {
          key: "hideDMShopTab",
          name: "Shop entry",
          desc: "Hides the Shop entry in the DM/Home sidebar.",
          default: true,
          css: [
            "a[href=\"/shop\"],",
            "a[data-list-item-id*=\"shop\"] {",
            "  display: none !important;",
            "}"
          ].join("\n")
        },
        {
          key: "hideDMQuestTab",
          name: "Quests entry",
          desc: "Hides the Quests entry in the DM/Home sidebar.",
          default: true,
          css: [
            "a[href=\"/quest-home\"],",
            "a[data-list-item-id*=\"quests\"],",
            "div[data-list-item-id*=\"quests\"] {",
            "  display: none !important;",
            "}"
          ].join("\n")
        },
        {
          key: "hideDMStoreTab",
          name: "Store entry",
          desc: "Hides the Store entry in the DM/Home sidebar.",
          default: true,
          css: [
            "a[href=\"/store\"],",
            "a[data-list-item-id*=\"store\"] {",
            "  display: none !important;",
            "}"
          ].join("\n")
        }
      ]
    },

    {
      section: "Profile Cosmetics",
      items: [
        {
          key: "hideProfileEffects",
          name: "Profile effects",
          desc: "Hides animated profile effects.",
          default: true,
          css: [
            "[class*=\"profileEffects_\"] {",
            "  display: none !important;",
            "}"
          ].join("\n")
        },
        {
          key: "hideAvatarDecorations",
          name: "Avatar decorations",
          desc: "Hides decorative overlays on avatars.",
          default: true,
          css: [
            "svg[class^=\"avatarDecoration_\"],",
            "img[class^=\"avatarDecoration_\"] {",
            "  display: none !important;",
            "}"
          ].join("\n")
        }
      ]
    },

    {
      section: "Member List & Account Area",
      items: [
        {
          key: "hideMemberListMedia",
          name: "Member list media tiles",
          desc: "Hides image/video tiles shown next to members (where present).",
          default: false,
          css: [
            "div[class*=\"member_\"] > div > div[class*=\"container_\"] > :is(div[class^=videoContainer_], img[class*=img_]) {",
            "  display: none !important;",
            "}"
          ].join("\n")
        },
        {
          key: "removeMemberListFade",
          name: "Member list background fades",
          desc: "Removes background fading behind member tiles that include media.",
          default: false,
          css: [
            "div[class*=\"member_\"] > div > div[class*=\"container_\"]:has(div[class^=videoContainer_], img[class*=img_]) {",
            "  background: none !important;",
            "}"
          ].join("\n")
        },
        {
          key: "hideSelfAccountMedia",
          name: "Account area media tiles",
          desc: "Hides image/video tiles in your own account area (where present).",
          default: false,
          css: [
            "div[class*=\"fitInAccount_\"] > :is(div[class^=videoContainer_], img[class*=img_]) {",
            "  display: none !important;",
            "}",
            "div[class*=\"fitInAccount_\"]:has(div[class^=videoContainer_], img[class*=img_]) {",
            "  background: none !important;",
            "}"
          ].join("\n")
        }
      ]
    },

    {
      section: "Identity & Badges",
      items: [
        {
          key: "hideClanTags",
          name: "Clan tags",
          desc: "Hides clan tags in chat, member lists, and profile popouts.",
          default: true,
          css: [
            "div[class^=body_] > span[class^=\"clickable_\"] [role=\"button\"],",
            "div[class*=compact_] span[class*=\"clanTagChiplet_\"],",
            "span[class*=\"clanTagChiplet_\"],",
            "span[class*=\"clanTag_\"] {",
            "  display: none !important;",
            "}"
          ].join("\n")
        }
      ]
    },

    {
      section: "Server Navigation",
      items: [
        {
          key: "hideServerDiscoverButton",
          name: "Discover servers button",
          desc: "Hides the 'Discover servers' button in the server list.",
          default: true,
          css: [
            "div[class*=\"listItem\"]:has(div[data-list-item-id=\"guildsnav___guild-discover-button\"]) {",
            "  display: none !important;",
            "}"
          ].join("\n")
        }
      ]
    },

    {
      section: "Reactions & Effects",
      items: [
        {
          key: "hideSuperReactionEffects",
          name: "Reaction visual effects",
          desc: "Reduces visual noise by hiding reaction effect overlays.",
          default: true,
          css: [
            "div[class^=\"effectsWrapper_\"] {",
            "  display: none !important;",
            "}"
          ].join("\n")
        },
        {
          key: "disableShakeReaction",
          name: "Reaction shake animation",
          desc: "Disables the shake animation applied to some reactions.",
          default: true,
          css: [
            "div[class*=\"shakeReaction_\"] {",
            "  animation: none !important;",
            "}"
          ].join("\n")
        }
      ]
    }
  ];

  // -----------------------------
  // Plugin
  // -----------------------------
  function DiscordHider() {
    this.pluginName = "DiscordHider";
    this.styleId = "DiscordHider-style";
    this.uiStyleId = "DiscordHider-ui-style";
    this.dataKey = "settings";
    this.settings = this._buildDefaultSettings();
  }

  // Legacy getters (max compatibility across BD setups)
  DiscordHider.prototype.getName = function () { return "Discord Hider"; };
  DiscordHider.prototype.getAuthor = function () { return "Crytix"; };
  DiscordHider.prototype.getDescription = function () {
    return "Hide selected Discord interface elements using simple, per-item toggles.";
  };
  DiscordHider.prototype.getVersion = function () { return "1.0.0"; };

  DiscordHider.prototype.start = function () {
    this._loadSettings();
    this._injectUiCss();
    this._apply(true);
  };

  DiscordHider.prototype.stop = function () {
    try { BdApi.DOM.removeStyle(this.styleId); } catch (e) {}
    try { BdApi.DOM.removeStyle(this.uiStyleId); } catch (e) {}
  };

  // -----------------------------
  // Settings
  // -----------------------------
  DiscordHider.prototype._buildDefaultSettings = function () {
    var defaults = {};
    for (var g = 0; g < OPTION_GROUPS.length; g++) {
      var group = OPTION_GROUPS[g];
      for (var i = 0; i < group.items.length; i++) {
        var item = group.items[i];
        defaults[item.key] = !!item.default;
      }
    }
    return defaults;
  };

  DiscordHider.prototype._loadSettings = function () {
    var saved = null;
    try { saved = BdApi.Data.load(this.pluginName, this.dataKey); } catch (e) {}

    var merged = this._buildDefaultSettings();
    if (saved && typeof saved === "object") {
      for (var k in saved) merged[k] = saved[k];
    }
    this.settings = merged;
  };

  DiscordHider.prototype._saveSettings = function () {
    try { BdApi.Data.save(this.pluginName, this.dataKey, this.settings); } catch (e) {}
  };

  // -----------------------------
  // CSS
  // -----------------------------
  DiscordHider.prototype._buildCss = function () {
    var chunks = [];
    for (var g = 0; g < OPTION_GROUPS.length; g++) {
      var group = OPTION_GROUPS[g];
      for (var i = 0; i < group.items.length; i++) {
        var item = group.items[i];
        if (this.settings[item.key]) {
          chunks.push("/* " + group.section + " — " + item.name + " */\n" + item.css);
        }
      }
    }
    return chunks.join("\n\n");
  };

  DiscordHider.prototype._apply = function (force) {
    var css = this._buildCss();
    try {
      if (force) BdApi.DOM.removeStyle(this.styleId);
      if (!css) {
        BdApi.DOM.removeStyle(this.styleId);
        return;
      }
      BdApi.DOM.addStyle(this.styleId, css);
    } catch (e) {
      try { console.error("[DiscordHider] Failed to apply styles:", e); } catch (_) {}
    }
  };

  // -----------------------------
  // UI (Discord-style switches)
  // -----------------------------
  DiscordHider.prototype._injectUiCss = function () {
    var uiCss = [
      ".dh-panel{padding:12px;}",
      ".dh-title{font-weight:800;font-size:16px;margin:0 0 10px;}",
      ".dh-section{margin-top:14px;}",
      ".dh-section-title{font-weight:800;font-size:12px;opacity:.9;margin:0 0 8px;text-transform:uppercase;letter-spacing:.02em;}",
      ".dh-row{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:10px 0;border-bottom:1px solid rgba(255,255,255,0.06);}",
      ".dh-row:last-child{border-bottom:0;}",
      ".dh-label{display:flex;flex-direction:column;gap:4px;}",
      ".dh-name{font-size:13px;font-weight:600;}",
      ".dh-desc{font-size:12px;opacity:.75;line-height:1.35;}",
      ".dh-switch{position:relative;width:42px;height:24px;border-radius:999px;background:rgba(255,255,255,0.10);border:1px solid rgba(255,255,255,0.14);cursor:pointer;flex:0 0 auto;transition:background .15s ease,border-color .15s ease;}",
      ".dh-switch[data-checked=\"true\"]{background:var(--brand-500,#5865f2);border-color:rgba(0,0,0,0.10);}",
      ".dh-switch:after{content:\"\";position:absolute;top:3px;left:3px;width:18px;height:18px;border-radius:999px;background:rgba(255,255,255,0.92);box-shadow:0 1px 2px rgba(0,0,0,0.35);transition:transform .15s ease;}",
      ".dh-switch[data-checked=\"true\"]:after{transform:translateX(18px);}"
    ].join("");

    try { BdApi.DOM.addStyle(this.uiStyleId, uiCss); } catch (e) {}
  };

  DiscordHider.prototype.getSettingsPanel = function () {
    var self = this;

    function el(tag, cls, text) {
      var node = document.createElement(tag);
      if (cls) node.className = cls;
      if (typeof text === "string") node.textContent = text;
      return node;
    }

    function section(titleText) {
      var s = el("div", "dh-section", null);
      s.appendChild(el("div", "dh-section-title", titleText));
      return s;
    }

    function switchRow(item) {
      var row = el("div", "dh-row", null);

      var left = el("div", "dh-label", null);
      left.appendChild(el("div", "dh-name", item.name));
      left.appendChild(el("div", "dh-desc", item.desc));

      var sw = el("div", "dh-switch", null);
      sw.setAttribute("role", "switch");
      sw.setAttribute("tabindex", "0");

      function sync() {
        var on = !!self.settings[item.key];
        sw.setAttribute("data-checked", on ? "true" : "false");
        sw.setAttribute("aria-checked", on ? "true" : "false");
      }

      function toggle() {
        self.settings[item.key] = !self.settings[item.key];
        self._saveSettings();
        self._apply(false);
        sync();
      }

      sw.addEventListener("click", toggle);
      sw.addEventListener("keydown", function (e) {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          toggle();
        }
      });

      sync();
      row.appendChild(left);
      row.appendChild(sw);
      return row;
    }

    var panel = el("div", "dh-panel", null);
    panel.appendChild(el("div", "dh-title", "Discord Hider"));

    for (var g = 0; g < OPTION_GROUPS.length; g++) {
      var group = OPTION_GROUPS[g];
      var sec = section(group.section);

      for (var i = 0; i < group.items.length; i++) {
        sec.appendChild(switchRow(group.items[i]));
      }

      panel.appendChild(sec);
    }

    return panel;
  };

  return DiscordHider;
})();
