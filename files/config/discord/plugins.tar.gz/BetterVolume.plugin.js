/**
 * @name BetterVolume
 * @version 3.2.3
 * @author Zerthox
 * @authorLink https://github.com/Zerthox
 * @description Set user volume values manually instead of using a slider. Allows setting volumes higher than 200%.
 * @website https://github.com/Zerthox/BetterDiscord-Plugins
 * @source https://github.com/Zerthox/BetterDiscord-Plugins/tree/master/src/BetterVolume
**/

/*@cc_on @if (@_jscript)
var pluginName = WScript.ScriptName.split(".")[0];
var shell = WScript.CreateObject("WScript.Shell");
shell.Popup(
    "Do NOT run scripts from the internet with the Windows Script Host!\nMove this file to your BetterDiscord plugins folder.",
    0,
    pluginName + ": Warning!",
    0x1030,
);
var fso = new ActiveXObject("Scripting.FileSystemObject");
var pluginsPath = shell.expandEnvironmentStrings("%appdata%\\BetterDiscord\\plugins");
if (!fso.FolderExists(pluginsPath)) {
    var popup = shell.Popup(
        "Unable to find BetterDiscord on your computer.\nOpen the download page of BetterDiscord?",
        0,
        pluginName + ": BetterDiscord not found",
        0x34,
    );
    if (popup === 6) {
        shell.Exec('explorer "https://betterdiscord.app"');
    }
} else if (WScript.ScriptFullName === pluginsPath + "\\" + WScript.ScriptName) {
    shell.Popup(
        'This plugin is already in the correct folder.\nNavigate to the "Plugins" settings tab in Discord and enable it there.',
        0,
        pluginName,
        0x40,
    );
} else {
    var popup = shell.Popup("Open the BetterDiscord plugins folder?", 0, pluginName, 0x34);
    if (popup === 6) {
        shell.Exec("explorer " + pluginsPath);
    }
}
WScript.Quit();
@else @*/

'use strict';

let meta = null;
const getMeta = () => {
    if (meta) {
        return meta;
    }
    else {
        throw Error("Accessing meta before initialization");
    }
};
const setMeta = (newMeta) => {
    meta = newMeta;
};

const load = (key) => BdApi.Data.load(getMeta().name, key);
const save = (key, value) => BdApi.Data.save(getMeta().name, key, value);

const checkObjectValues = (target) => target !== window && target instanceof Object && target.constructor?.prototype !== target;
const byName$1 = (name) => {
    return (target) => (target?.displayName ?? target?.constructor?.displayName) === name;
};
const byKeys$1 = (...keys) => {
    return (target) => target instanceof Object && keys.every((key) => key in target);
};
const bySource$1 = (...fragments) => {
    return (target) => {
        while (target instanceof Object && "$$typeof" in target) {
            target = target.render ?? target.type;
        }
        if (target instanceof Function) {
            const source = target.toString();
            const renderSource = target.prototype?.render?.toString();
            return fragments.every((fragment) => typeof fragment === "string"
                ? source.includes(fragment) || renderSource?.includes(fragment)
                : fragment(source) || (renderSource && fragment(renderSource)));
        }
        else {
            return false;
        }
    };
};

const confirm = (title, content, options = {}) => BdApi.UI.showConfirmationModal(title, content, options);
const mappedProxy = (target, mapping) => {
    const map = new Map(Object.entries(mapping));
    return new Proxy(target, {
        get(target, prop) {
            return target[map.get(prop) ?? prop];
        },
        set(target, prop, value) {
            target[map.get(prop) ?? prop] = value;
            return true;
        },
        deleteProperty(target, prop) {
            delete target[map.get(prop) ?? prop];
            map.delete(prop);
            return true;
        },
        has(target, prop) {
            return map.has(prop) || prop in target;
        },
        ownKeys() {
            return [...map.keys(), ...Object.keys(target)];
        },
        getOwnPropertyDescriptor(target, prop) {
            return Object.getOwnPropertyDescriptor(target, map.get(prop) ?? prop);
        },
        defineProperty(target, prop, attributes) {
            Object.defineProperty(target, map.get(prop) ?? prop, attributes);
            return true;
        },
    });
};

const find = (filter, { resolve = true, entries = false } = {}) => BdApi.Webpack.getModule(filter, {
    defaultExport: resolve,
    searchExports: entries,
});
const byName = (name, options) => find(byName$1(name), options);
const byKeys = (keys, options) => find(byKeys$1(...keys), options);
const bySource = (contents, options) => find(bySource$1(...contents), options);
const resolveKey = (target, filter) => [
    target,
    (target ? Object.entries(target).find(([, value]) => filter(value))?.[0] : null),
];
const demangle = (mapping, required, proxy = false) => {
    const req = Object.keys(mapping);
    const found = find((target) => checkObjectValues(target)
        && req.every((req) => Object.values(target).some((value) => mapping[req](value))));
    return proxy
        ? mappedProxy(found, Object.fromEntries(Object.entries(mapping).map(([key, filter]) => [
            key,
            Object.entries(found ?? {}).find(([, value]) => filter(value))?.[0],
        ])))
        : Object.fromEntries(Object.entries(mapping).map(([key, filter]) => [
            key,
            Object.values(found ?? {}).find((value) => filter(value)),
        ]));
};
let controller = new AbortController();
const waitFor = (filter, { resolve = true, entries = false } = {}) => BdApi.Webpack.waitForModule(filter, {
    signal: controller.signal,
    defaultExport: resolve,
    searchExports: entries,
});
const abort = () => {
    controller.abort();
    controller = new AbortController();
};

const COLOR = "#3a71c1";
const print = (output, ...data) => output(`%c[${getMeta().name}] %c${getMeta().version ? `(v${getMeta().version})` : ""}`, `color: ${COLOR}; font-weight: 700;`, "color: #666; font-size: .8em;", ...data);
const log = (...data) => print(console.log, ...data);
const warn = (...data) => print(console.warn, ...data);

const patch = (type, object, method, callback, options) => {
    const original = object?.[method];
    const name = options.name ?? String(method);
    if (!(original instanceof Function)) {
        throw TypeError(`patch target ${name} is ${original} not function`);
    }
    const cancel = BdApi.Patcher[type](getMeta().name, object, method, options.once
        ? (...args) => {
            const result = callback(cancel, original, ...args);
            cancel();
            return result;
        }
        : (...args) => callback(cancel, original, ...args));
    if (!options.silent) {
        log(`Patched ${name}`);
    }
    return cancel;
};
const after = (object, method, callback, options = {}) => patch("after", object, method, (cancel, original, context, args, result) => callback({ cancel, original, context, args, result }), options);
let menuPatches = [];
const unpatchAll = () => {
    if (menuPatches.length + BdApi.Patcher.getPatchesByCaller(getMeta().name).length > 0) {
        for (const cancel of menuPatches) {
            cancel();
        }
        menuPatches = [];
        BdApi.Patcher.unpatchAll(getMeta().name);
        log("Unpatched all");
    }
};

const inject = (styles) => {
    if (typeof styles === "string") {
        BdApi.DOM.addStyle(getMeta().name, styles);
    }
};
const clear = () => BdApi.DOM.removeStyle(getMeta().name);

const Dispatcher = /* @__PURE__ */ byKeys(["dispatch", "subscribe"], { entries: true });

const MediaEngineStore = /* @__PURE__ */ byName("MediaEngineStore");
const MediaEngineActions = /* @__PURE__ */ byKeys(["setLocalVolume"]);

const { React } = BdApi;

const AudioConvert = /* @__PURE__ */ demangle({
    amplitudeToPerceptual: bySource$1("Math.log10"),
    perceptualToAmplitude: bySource$1("Math.pow(10"),
});

const Button = /* @__PURE__ */ byKeys(["Colors", "Link"], { entries: true });

const Flex = /* @__PURE__ */ byKeys(["Child", "Justify", "Align"], { entries: true });

const FormDivider = /* @__PURE__ */ bySource(["marginTop:", (source) => /{className:.,gap:.}=/.test(source)], {
    entries: true,
});

const { Item: MenuItem} = BdApi.ContextMenu;

const SettingsContainer = ({ name, children, onReset }) => (React.createElement("div", null,
    children,
    onReset ? (React.createElement(React.Fragment, null,
        React.createElement(FormDivider, { gap: 20 }),
        React.createElement(Flex, { justify: Flex.Justify.END },
            React.createElement(Button, { size: Button.Sizes.SMALL, onClick: () => confirm(name, "Reset all settings?", {
                    onConfirm: onReset,
                }) }, "Reset")))) : null));

class SettingsStore {
    defaults;
    current;
    onLoad;
    listeners = new Set();
    constructor(defaults, onLoad) {
        this.defaults = defaults;
        this.onLoad = onLoad;
    }
    load() {
        this.current = { ...this.defaults, ...load("settings") };
        this.onLoad?.();
        this._dispatch(false);
    }
    _dispatch(save$1) {
        for (const listener of this.listeners) {
            listener(this.current);
        }
        if (save$1) {
            save("settings", this.current);
        }
    }
    getCurrent = () => this.current;
    update = (settings) => {
        const update = typeof settings === "function" ? settings(this.current) : settings;
        this.current = { ...this.current, ...update };
        this._dispatch(true);
    };
    reset() {
        this.current = { ...this.defaults };
        this._dispatch(true);
    }
    delete(...keys) {
        this.current = { ...this.current };
        for (const key of keys) {
            delete this.current[key];
        }
        this._dispatch(true);
    }
    useCurrent() {
        return React.useSyncExternalStore(this.addListenerEffect, this.getCurrent);
    }
    useSelector(selector, deps = null, compare = Object.is) {
        const state = React.useRef(null);
        const snapshot = React.useCallback(() => {
            const next = selector(this.current);
            if (!compare(state.current, next)) {
                state.current = next;
            }
            return state.current;
        }, deps ?? [selector]);
        return React.useSyncExternalStore(this.addListenerEffect, snapshot);
    }
    useState() {
        const current = this.useCurrent();
        return [current, this.update];
    }
    useStateWithDefaults() {
        const current = this.useCurrent();
        return [current, this.defaults, this.update];
    }
    useListener(listener, deps) {
        React.useEffect(() => this.addListenerEffect(listener), deps ?? [listener]);
    }
    addListener(listener) {
        this.listeners.add(listener);
        return listener;
    }
    addListenerEffect = (listener) => {
        this.addListener(listener);
        return () => this.removeListener(listener);
    };
    removeListener(listener) {
        this.listeners.delete(listener);
    }
    removeAllListeners() {
        this.listeners.clear();
    }
    addReactChangeListener = this.addListener;
    removeReactChangeListener = this.removeListener;
}
const createSettings = (defaults, onLoad) => new SettingsStore(defaults, onLoad);

const createPlugin = (plugin) => (meta) => {
    setMeta(meta);
    const { start, stop, styles, Settings, SettingsPanel } = plugin instanceof Function ? plugin(meta) : plugin;
    Settings?.load();
    return {
        start() {
            log("Enabled");
            inject(styles);
            start?.();
        },
        stop() {
            abort();
            unpatchAll();
            clear();
            stop?.();
            log("Disabled");
        },
        getSettingsPanel: SettingsPanel
            ? () => (React.createElement(SettingsContainer, { name: meta.name, onReset: Settings ? () => Settings.reset() : null },
                React.createElement(SettingsPanel, null)))
            : null,
    };
};

const Settings = createSettings({
    volumeOverrides: {},
    disableExperiment: null,
});
const hasOverride = (userId, context) => context in (Settings.current.volumeOverrides[userId] ?? {});
const updateVolumeOverride = (userId, volume, context) => {
    const isNew = !hasOverride(userId, context);
    Settings.update(({ volumeOverrides }) => {
        volumeOverrides[userId] = { [context]: volume, ...volumeOverrides[userId] };
        return { volumeOverrides };
    });
    return isNew;
};
const tryResetVolumeOverride = (userId, context) => {
    if (hasOverride(userId, context)) {
        Settings.update(({ volumeOverrides }) => {
            delete volumeOverrides[userId][context];
            if (Object.keys(volumeOverrides[userId]).length === 0) {
                delete volumeOverrides[userId];
            }
            return { volumeOverrides };
        });
        return true;
    }
    return false;
};

const css = ".container-BetterVolume{margin:0 8px;padding:3px 6px;display:flex;background:var(--input-background);border:1px solid var(--input-border-default);border-radius:3px}.input-BetterVolume{margin-right:2px;flex-grow:1;background:rgba(0,0,0,0);border:none}.input-BetterVolume::-webkit-inner-spin-button{appearance:none}.input-BetterVolume:hover::-webkit-inner-spin-button{appearance:auto}.input-BetterVolume,.unit-BetterVolume{color:var(--input-foreground-default);font-family:var(--font-primary);font-weight:500}";
const styles = {
    container: "container-BetterVolume",
    input: "input-BetterVolume",
    unit: "unit-BetterVolume"
};

const limit = (input, min, max) => Math.min(Math.max(input, min), max);
const NumberInput = ({ value, min, max, fallback, onChange }) => {
    const [isEmpty, setEmpty] = React.useState(false);
    return (React.createElement("div", { className: styles.container },
        React.createElement("input", { type: "number", className: styles.input, min: min, max: max, value: !isEmpty ? Math.round((value + Number.EPSILON) * 100) / 100 : "", onChange: ({ target }) => {
                const value = limit(parseFloat(target.value), min, max);
                const isNaN = Number.isNaN(value);
                setEmpty(isNaN);
                if (!isNaN) {
                    onChange(value);
                }
            }, onBlur: () => {
                if (isEmpty) {
                    setEmpty(false);
                    onChange(fallback);
                }
            } }),
        React.createElement("span", { className: styles.unit }, "%")));
};

const MAX_VOLUME_PERC = 200;
const MAX_VOLUME_AMP = AudioConvert.perceptualToAmplitude(MAX_VOLUME_PERC);
const dispatchVolumeOverrides = () => {
    log("Dispatching volume overrides");
    for (const [userId, contexts] of Object.entries(Settings.current.volumeOverrides)) {
        for (const [context, volume] of Object.entries(contexts)) {
            Dispatcher.dispatch({
                type: "AUDIO_SET_LOCAL_VOLUME" ,
                userId,
                context,
                volume,
            });
        }
    }
};
const findAudioSettingsManager = () => {
    const hasSetVolume = byKeys$1("AUDIO_SET_LOCAL_VOLUME" );
    return find((exported) => exported.actions && hasSetVolume(exported.actions));
};
const handleAudioSettingsManager = (AudioSettingsManager) => {
    originalHandler = AudioSettingsManager.actions["AUDIO_SET_LOCAL_VOLUME" ];
    const swapped = trySwapHandler("AUDIO_SET_LOCAL_VOLUME" , originalHandler, wrappedSettingsManagerHandler);
    if (swapped) {
        log(`Replaced AudioSettingsManager ${"AUDIO_SET_LOCAL_VOLUME" } handler`);
        dispatchVolumeOverrides();
        Dispatcher.subscribe("USER_SETTINGS_PROTO_UPDATE" , dispatchVolumeOverrides);
        log(`Subscribed to ${"USER_SETTINGS_PROTO_UPDATE" } events`);
    }
    else {
        warn(`AudioSettingsManager ${"AUDIO_SET_LOCAL_VOLUME" } handler not present`);
    }
};
const postConnectionOpenHandler = (_action) => {
    log(`Received ${"POST_CONNECTION_OPEN" }`);
    const AudioSettingsManager = findAudioSettingsManager();
    if (AudioSettingsManager) {
        handleAudioSettingsManager(AudioSettingsManager);
    }
    else {
        warn("Failed to find AudioSettingsManager");
    }
};
let originalHandler = null;
const wrappedSettingsManagerHandler = (action) => {
    const { userId, volume, context } = action;
    const isOverride = volume > MAX_VOLUME_AMP;
    if (isOverride) {
        const isNew = updateVolumeOverride(userId, volume, context);
        if (isNew) {
            log(`New volume override ${AudioConvert.amplitudeToPerceptual(volume)} for user ${userId} context ${context}`);
            originalHandler({ ...action, volume: MAX_VOLUME_AMP });
        }
    }
    else {
        const wasRemoved = tryResetVolumeOverride(userId, context);
        if (wasRemoved) {
            log(`Removed volume override for user ${userId} context ${context}`);
        }
        originalHandler(action);
    }
};
const trySwapHandler = (action, prev, next) => {
    const isPresent = Dispatcher._subscriptions[action].has(prev);
    if (isPresent) {
        Dispatcher.unsubscribe(action, prev);
        Dispatcher.subscribe(action, next);
    }
    return isPresent;
};
const handleVolumeSync = () => {
    Dispatcher.subscribe("POST_CONNECTION_OPEN" , postConnectionOpenHandler);
    log(`Subscribed to ${"POST_CONNECTION_OPEN" } events`);
    const AudioSettingsManager = findAudioSettingsManager();
    if (AudioSettingsManager) {
        handleAudioSettingsManager(AudioSettingsManager);
    }
    else {
        log(`AudioSettingsManager not found, waiting for ${"POST_CONNECTION_OPEN" }`);
    }
};
const resetVolumeSync = () => {
    Dispatcher.unsubscribe("POST_CONNECTION_OPEN" , postConnectionOpenHandler);
    log(`Unsubscribed from ${"POST_CONNECTION_OPEN" } events`);
    Dispatcher.unsubscribe("USER_SETTINGS_PROTO_UPDATE" , dispatchVolumeOverrides);
    log(`Unsubscribed from ${"USER_SETTINGS_PROTO_UPDATE" } events`);
    const swapped = trySwapHandler("AUDIO_SET_LOCAL_VOLUME" , wrappedSettingsManagerHandler, originalHandler);
    if (swapped) {
        log(`Reset ${"AUDIO_SET_LOCAL_VOLUME" } handler`);
    }
};

const useUserVolumeItemFilter = bySource$1("user-volume");
const index = createPlugin({
    start() {
        handleVolumeSync();
        waitFor(useUserVolumeItemFilter, { resolve: false }).then((result) => {
            const useUserVolumeItem = resolveKey(result, useUserVolumeItemFilter);
            after(...useUserVolumeItem, ({ args: [userId, context], result }) => {
                if (result) {
                    const volume = MediaEngineStore.getLocalVolume(userId, context);
                    return (React.createElement(React.Fragment, null,
                        result,
                        React.createElement(MenuItem, { id: "user-volume-input", render: () => (React.createElement(NumberInput, { value: AudioConvert.amplitudeToPerceptual(volume), min: 0, max: 999999, fallback: 100, onChange: (value) => MediaEngineActions.setLocalVolume(userId, AudioConvert.perceptualToAmplitude(value), context) })) })));
                }
            }, { name: "useUserVolumeItem" });
        });
    },
    stop() {
        resetVolumeSync();
    },
    styles: css,
    Settings,
});

module.exports = index;

/*@end @*/
